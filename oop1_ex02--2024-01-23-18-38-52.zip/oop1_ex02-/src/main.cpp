﻿#include "Controller.h"

int main()
{
    auto control = Controller();
    control.run();
}

