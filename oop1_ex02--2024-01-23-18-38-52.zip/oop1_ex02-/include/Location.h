#pragma once

struct Location
{
    int row;
    int col;

    Location() = default;

    Location(int row,int col) : row(row) ,col(col){}

};
